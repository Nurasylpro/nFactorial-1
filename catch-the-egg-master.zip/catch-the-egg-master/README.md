# Catch The Egg
Made just for fun. [Play it here!](https://shtange.github.io/catch-the-egg/)

## Screenshot
![alt text](https://raw.githubusercontent.com/shtange/catch-the-egg/master/catch-the-egg-screen.jpg "Catch The Egg")

## Publications
Review on [Habrahabr](https://habr.com/ru/post/261669/) (russian language)

## License
Released under the [MIT License](http://www.opensource.org/licenses/mit-license.php)
